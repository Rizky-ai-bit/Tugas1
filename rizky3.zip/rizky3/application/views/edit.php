<div class="container-fluid">
<div class="content-wrapper">
	<section class="content">
		<?php foreach($pasrah as $siswa) { ?>

		<form action="<?php echo base_url(). 'data/update'; ?>" method="post">
			
			<div class="form-group">
				<label>Nama</label>
				<input type="hidden" name="id" class="form-control" value="<?php echo $siswa->id ?>">
				<input type="text" name="nama" class="form-control" value="<?php echo $siswa->nama ?>">
			</div>

			<div class="form-group">
				<label>NIM</label>
				<input type="text" name="nim" class="form-control" value="<?php echo $siswa->nim ?>">
			</div>

			<div class="form-group">
				<label>Tanggal Lahir</label>
				<input type="date" name="tgl_lahir" class="form-control" value="<?php echo $siswa->tgl_lahir ?>">
			</div>

			<div class="form-group">
				<label>Jenis Kelamin</label>

				<select type="text" name="jk" value="<?php echo $siswa->jk ?>">
	              <option>Laki-Laki</option>
	              <option>Perempuan</option>
	            </select>
			</div>

			<div class="form-group">
				<label>Alamat</label>
				<input type="text" name="alamat" class="form-control" value="<?php echo $siswa->alamat ?>">
			</div>

			<button type="reset" class="btn btn-danger">Reset</button>
			<button type="submit" class="btn btn-primary">Simpan</button>

		</form>
		<?php } ?>
	</section>
</div>
</div>