<div class="container-fluid">
  <div class="contet-wrapper">
	<section class="content-header">
      <h1>
        Data Diri
      </h1>
      <ol class="breadcrumb">
      </ol>
    </section>
    <section class="content">
    	<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambah">Tambah Data</button>

		<table class="table">
			<tr>
				<th>NO</th>
				<th>NAMA</th>
				<th>NIM</th>
				<th>Tanggal Lahir</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
        <th>Aksi</th>
			</tr>

			<?php 

			$no = 1;
			foreach ($pasrah as $siswa) : ?>

			<tr>
				<td><?php echo $no++ ?></td>
				<td><?php echo $siswa->nama ?></td>
				<td><?php echo $siswa->nim ?></td>
				<td><?php echo $siswa->tgl_lahir ?></td>
				<td><?php echo $siswa->jk ?></td>
				<td><?php echo $siswa->alamat ?></td>
        <td onclick="javascript: return confirm('Anda yakin mau menghapus data?')"><?php echo anchor('data/hapus/'. $siswa->id, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>') ?></td>
        <td><?php echo anchor('data/edit/'. $siswa->id, '<div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div>') ?></td>
			</tr>
			<?php endforeach; ?>

		</table>
	</section>
</div>

<!-- Modal -->
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <?php echo form_open_multipart('data/tambah_aksi'); ?>

<div class="mb-3">
  <label class="form-label">Nama</label>
  <input type="hidden" name="id" class="form-control" value="<?php echo $siswa->id ?>">
  <input type="text" name="nama" class="form-control" value="<?php echo $siswa->nama ?>">
</div>

<div class="mb-3">
  <label class="form-label">NIM</label>
  <input type="text" name="nim" class="form-control" value="<?php echo $siswa->nim ?>">
</div>

<div class="mb-3">
  <label class="form-label">Tanggal Lahir</label>
  <input type="date" name="tgl_lahir" class="form-control" value="<?php echo $siswa->tgl_lahir ?>">
</div>

<div class="mb-3">
  <label class="form-label">Jenis Kelamin</label>
  <select name="jk" class="form-select" value="<?php echo $siswa->jk ?>">
    <option value="Laki-Laki" >Laki-Laki</option>
    <option value="Perempuan">Perempuan</option>
  </select>
</div>

<div class="mb-3">
  <label class="form-label">Alamat</label>
  <input type="text" name="alamat" class="form-control" value="<?php echo $siswa->alamat ?>">
</div>

<div class="modal-footer">
  <button type="reset" class="btn btn-danger" data-bs-dismiss="modal">Reset</button>
  <button type="submit" class="btn btn-primary">Simpan</button>
</div>

<?php echo form_close(); ?>
</div>
      </div>
    </div>
  </div>
</div>

</div>
</div>
