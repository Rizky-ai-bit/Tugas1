<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tambah Data Diri</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container my-4">

  <h1 class="mb-4">Data Diri</h1>

  <div class="mb-3">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
      <i class="fa fa-plus"></i> Tambah Data
    </button>
  </div>

  <table class="table table-bordered">
    <thead class="table-light">
      <tr>
      	<th>No</th>
        <th>Nama</th>
        <th>NIM</th>
        <th>Tanggal Lahir</th>
        <th>Jenis Kelamin</th>
        <th>Alamat</th>
      </tr>
    </thead>
    <tbody>
      <?php 
		$no = 1;
      foreach ($diri as $profil) : ?>
        <tr>
        		<td><?= $no++ ?></td>
            <td><?= $profil->nama ?></td>
            <td><?= $profil['nim']; ?></td>
            <td><?= $profil['tgl_lahir']; ?></td>
            <td><?= $profil['jk']; ?></td>
            <td><?= $profil['alamat']; ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="exampleModalLabel">Form Input Data Diri</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <?php echo form_open_multipart('kyy/tambah_aksi'); ?>

          <div class="mb-3">
            <label class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label">NIM</label>
            <input type="text" name="nim" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label">Tanggal Lahir</label>
            <input type="date" name="tgl_lahir" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label">Jenis Kelamin</label>
            <select name="jk" class="form-select">
              <option value="Laki-Laki" >Laki-Laki</option>
              <option value="Perempuan">Perempuan</option>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Alamat</label>
            <input type="text" name="alamat" class="form-control">
          </div>

          <div class="modal-footer">
            <button type="reset" class="btn btn-danger" data-bs-dismiss="modal">Reset</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>

          <?php echo form_close(); ?>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
