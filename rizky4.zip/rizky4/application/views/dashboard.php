<!--  Header End -->
<div class="container-fluid">
  <!--  Row 1 -->
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Data Diri
      </h1>
      <ol class="breadcrumb">
      </ol>
    </section>

    <section class="content">
      <a href="<?php echo base_url('data/tambah_aksi');?>" class="btn btn-primary">Tambah Data</a>

      <table class="table">
        <tr>
          <th>NO</th>
          <th>NAMA</th>
          <th>NIM</th>
          <th>TANGGAL LAHIR</th>
          <th>JENIS KELAMIN</th>
          <th>ALAMAT</th>
        </tr>

        <?php

        $no = 1;
        foreach ($diri as $profil) : ?>

          <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $profil->nama ?></td>
            <td><?php echo $profil->nim ?></td>
            <td><?php echo $profil->tgl_lahir ?></td>
            <td><?php echo $profil->jk ?></td>
            <td><?php echo $profil->alamat ?></td>
          </tr>

        <?php endforeach; ?>

      </table>
    </section>
  </div>

</div>