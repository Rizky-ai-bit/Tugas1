<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>
<div class="container-fluid">
  <!--  Row 1 -->
  <div class="content-wrapper">
<div class="row">
  <div class="col-12">
    <h2 class="mb-4">Daftar Album</h2>
  </div>

  <section class="content">
      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambah">Tambah Album</button>

        
    </section>

  <?php if (count($albums) > 0): ?>
      <?php foreach ($albums as $album): ?>
          <div class="col-md-4 mb-4">
              <div class="card h-100 shadow">
                  <div class="card-body">
                      <h5 class="card-title"><?= $album->nama_album; ?></h5>
                      <p class="card-text">Deskripsi: <?= $album->deskripsi ?? 'Tidak ada deskripsi'; ?></p>
                  </div>
              </div>
          </div>
      <?php endforeach; ?>
  <?php else: ?>
      <div class="col-12">
        <div class="alert alert-info">Belum ada album.</div>
      </div>
  <?php endif; ?>

  <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

        <?php echo form_open_multipart('album/tambah_aksi'); ?>

      <div class="modal-body">
        <div class="mb-3">
            <label class="form-label">Nama Album</label>
            <input type="hidden" name="id" class="form-control">
            <input type="text" name="nama_album" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Deskripsi</label>
            <input type="text" name="deskripsi" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>

        <?php echo form_close(); ?>

    </div>
  </div>
</div>
</div>
</div>
</div>

<?php $this->load->view('templates/footer'); ?>
