<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_kyy');
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function index()
    {
        $data['diri'] = $this->M_kyy->tampil_data()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('dashboard', $data);
        $this->load->view('templates/footer');
    }

    public function tambah(){
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('tambah');
        $this->load->view('templates/footer');
    }

    public function album()
    {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('album');
        $this->load->view('templates/footer');
    }

    public function tambah_aksi() 
    {
        $nama       = $this->input->post('nama');
        $nim        = $this->input->post('nim');
        $tgl_lahir  = $this->input->post('tgl_lahir');
        $jk         = $this->input->post('jk');
        $alamat     = $this->input->post('alamat');
       
        $data = array(
            'nama'      => $nama,
            'nim'       => $nim,
            'tgl_lahir' => $tgl_lahir,
            'jk'        => $jk,
            'alamat'    => $alamat
        );

        $this->M_kyy->input_data($data,'tb_profil');
        redirect('admin/index');
    }
}
