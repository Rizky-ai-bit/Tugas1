<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Album extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('m_album'); // load model jika diperlukan
    }

    public function index() {
        $data['albums'] = $this->M_album->get_all(); // ambil data album dari model
        $this->load->view('album', $data); // tampilkan view
    }

    public function tambah_aksi() 
    {
        $nama_album       = $this->input->post('nama_album');
        $deskripsi        = $this->input->post('deskripsi');
       
        $data = array(
            'nama_album'      => $nama_album,
            'deskripsi'       => $deskripsi,
        );

        $this->M_album->input_data($data,'album');
        redirect('album/index');
    }

     public function hapus($id)
    {
        $where = array ('id' => $id);
        $this->M_album->hapus_data($where, 'album');
        $this->session->set_flashdata('message','<div class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              Data Berhasil Dihapus!!
            </div>');
        redirect('album/index');
    }

    public function edit($id)
    {
        $where = array('id' =>$id);
        $data['albums'] = $this->M_album->edit_data($where, 'album')->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('edit', $data);
        $this->load->view('templates/footer');
    }

    public function update()
    {
        $id         = $this->input->post('id');
        $nama_album       = $this->input->post('nama_album');
        $deskripsi        = $this->input->post('deskripsi');

        $data = array(
            'nama_album'      => $nama_album,
            'deskripsi'       => $deskripsi
        );

        $where = array(
            'id' => $id 
        );

        $this->M_album->update_data($where, $data, 'tb_profil');
        $this->session->set_flashdata('message','<div class="alert alert-info alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              Data Berhasil Diupdate!!
            </div>');
        redirect('album/index');
    }
}
