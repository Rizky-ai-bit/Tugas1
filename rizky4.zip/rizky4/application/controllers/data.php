<?php

class Data Extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_data');
    }

	public function index()
	{
		$data['pasrah'] = $this->M_data->tampil_data()->result();
		$this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('data', $data);
        $this->load->view('templates/footer');
	}

	public function tambah_aksi() 
    {
        $nama       = $this->input->post('nama');
        $nim        = $this->input->post('nim');
        $tgl_lahir  = $this->input->post('tgl_lahir');
        $jk         = $this->input->post('jk');
        $alamat     = $this->input->post('alamat');
       
        $data = array(
            'nama'      => $nama,
            'nim'       => $nim,
            'tgl_lahir' => $tgl_lahir,
            'jk'        => $jk,
            'alamat'    => $alamat
        );

        $this->M_data->input_data($data,'tb_profil');
        redirect('data/index');
    }

     public function hapus($id)
    {
        $where = array ('id' => $id);
        $this->M_data->hapus_data($where, 'tb_profil');
        $this->session->set_flashdata('message','<div class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              Data Berhasil Dihapus!!
            </div>');
        redirect('data/index');
    }

    public function edit($id)
    {
        $where = array('id' =>$id);
        $data['pasrah'] = $this->M_data->edit_data($where, 'tb_profil')->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('edit', $data);
        $this->load->view('templates/footer');
    }

    public function update()
    {
        $id         = $this->input->post('id');
        $nama       = $this->input->post('nama');
        $nim        = $this->input->post('nim');
        $tgl_lahir  = $this->input->post('tgl_lahir');
        $jk         = $this->input->post('jk');
        $alamat     = $this->input->post('alamat');

        $data = array(
            'nama'      => $nama,
            'nim'       => $nim,
            'tgl_lahir' => $tgl_lahir,
            'jk'        => $jk,
            'alamat'    => $alamat
        );

        $where = array(
            'id' => $id 
        );

        $this->M_data->update_data($where, $data, 'tb_profil');
        $this->session->set_flashdata('message','<div class="alert alert-info alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              Data Berhasil Diupdate!!
            </div>');
        redirect('data/index');
    }
}