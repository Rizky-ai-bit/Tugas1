<?php
class M_login extends CI_Model
{
	public function proses_login($user, $pass)
	{
		$password = $pass; // gunakan md5($pass) jika data di database dienkripsi
		
		// jangan overwrite $user dan $pass!
		$this->db->where('username', $user);
		$this->db->where('password', $password);
		$query = $this->db->get('login');

		if ($query->num_rows() > 0) {
			$row = $query->row();
			$sess = array(
				'id'       => $row->id,
				'nama'     => $row->nama,
				'username' => $row->username,
				'password' => $row->password,
				'level'    => $row->level,
			);
			$this->session->set_userdata($sess);
			redirect('data/index');
		} else {
			$this->session->set_flashdata('info', '<div class="alert alert-danger" role="alert">Login Gagal, Silahkan Periksa Username dan Password !!!<button type="button" class="btn-close position-absolute top-50 end-0 translate-middle-y me-2" data-bs-dismiss="alert"
				aria-label="Close"></button></div>');
			redirect('login');  
		}
	}
}
