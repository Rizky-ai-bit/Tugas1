<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>
<div class="container-fluid">
  <!-- Row 1 -->
  <div class="content-wrapper">
    <div class="row">
      <div class="col-12">
        <h2 class="mb-4">Daftar Album</h2>
      </div>

      <section class="content mb-3">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambah">Tambah Album</button>
      </section>

      <?php if (count($albums) > 0): ?>
        <?php foreach ($albums as $album): ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100 shadow">
              <div class="card-body">
                <h5 class="card-title"><?= $album->nama_album; ?></h5>
                <p class="card-text">Deskripsi: <?= $album->deskripsi ?? 'Tidak ada deskripsi'; ?></p>

                <!-- Tombol Edit dan Hapus -->
                <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?= $album->id; ?>">Edit</button>
                <a href="<?= base_url('album/hapus/' . $album->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus album ini?')">Hapus</a>

                <!-- href -->
                  <!-- href -->
                  <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling">Tampilkan Foto</button>

                  <div class="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
                    <div class="offcanvas-header">
                      <h5 class="offcanvas-title" id="offcanvasScrollingLabel">Lihat Foto</h5>
                      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                      <div class="card" style="width: 250px;
                    margin: auto;">
                    <img src="<?php echo base_url() ?>assets/images/img/tanjiro.webp" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title">Demon Slayer</h5>
                      <p class="card-text">Kepribadiannya… baik, setia, dan penuh hormat . Dia bahkan berbelas kasih kepada iblis yang dia hadapi dalam pertempuran, sering berdoa di atas tubuh mereka setelah dia mengalahkan mereka.</p>
                      <a href="<?= base_url()?>album/index" class="btn btn-primary">Kembali</a>
                    </div>
                  </div>
                    </div>
                  </div>
                <!-- end href -->
                <!-- end href -->

              </div>
            </div>
          </div>

          

          <!-- Modal Edit Album -->
          <div class="modal fade" id="edit<?= $album->id; ?>" tabindex="-1" aria-labelledby="editLabel<?= $album->id; ?>" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="editLabel<?= $album->id; ?>">Edit Album</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <?php echo form_open_multipart('album/update'); ?>
                <div class="modal-body">
                  <input type="hidden" name="id" value="<?= $album->id; ?>">
                  <div class="mb-3">
                    <label class="form-label">Nama Album</label>
                    <input type="text" name="nama_album" class="form-control" value="<?= $album->nama_album; ?>">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Deskripsi</label>
                    <input type="text" name="deskripsi" class="form-control" value="<?= $album->deskripsi; ?>">
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <?php echo form_close(); ?>

              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="col-12">
          <div class="alert alert-info">Belum ada album.</div>
        </div>
      <?php endif; ?>

      <!-- Modal Tambah Album -->
      <div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Album</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <?php echo form_open_multipart('album/tambah_aksi'); ?>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">Nama Album</label>
                <input type="text" name="nama_album" class="form-control">
              </div>
              <div class="mb-3">
                <label class="form-label">Deskripsi</label>
                <input type="text" name="deskripsi" class="form-control">
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            <?php echo form_close(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('templates/footer'); ?>
