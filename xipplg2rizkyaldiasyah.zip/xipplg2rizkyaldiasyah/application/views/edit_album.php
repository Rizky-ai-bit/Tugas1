<div class="container-fluid">
<div class="content-wrapper">
	<section class="content">
		<?php foreach($albums as $album) { ?>

		<form action="<?php echo base_url(). 'album/update'; ?>" method="post">
			
			<div class="form-group">
				<label>Nama Album</label>
				<input type="hidden" name="id" class="form-control" value="<?php echo $album->id ?>">
				<input type="text" name="nama_album" class="form-control" value="<?php echo $album->nama_album ?>">
			</div>

			<div class="form-group">
				<label>Deskripsi</label>
				<input type="text" name="deskripsi" class="form-control" value="<?php echo $album->deskripsi ?>">
			</div>

			<button type="reset" class="btn btn-danger">Reset</button>
			<button type="submit" class="btn btn-primary">Simpan</button>

		</form>
		<?php } ?>
	</section>
</div>
</div>